# -*- coding: utf-8 -*-
import pymongo
from scrapy.conf import settings



class HeartsongPipeline(object):
    def __init__(self):
        
        self.client = pymongo.MongoClient(host=settings['MONGO_HOST'], port=settings['MONGO_PORT'])
        self.db = self.client[settings['MONGO_DB']]  
        self.coll = self.db[settings['MONGO_COLL']]  

    def process_item(self, item, spider):
        postItem = dict(item)  
        self.coll.insert(postItem)  
        return item  

