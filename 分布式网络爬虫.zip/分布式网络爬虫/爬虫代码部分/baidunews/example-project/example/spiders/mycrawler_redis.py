#coding=utf-8#
from scrapy.spiders import Rule
from scrapy.linkextractors import LinkExtractor
from scrapy_redis.spiders import RedisCrawlSpider

import scrapy
from scrapy.http import Request
from example.items import ExampleItem
import re
import urllib2
import requests
import time

import sys
reload(sys)
sys.setdefaultencoding('utf8')


class MyCrawler(RedisCrawlSpider):
    """Spider that reads urls from redis queue (myspider:start_urls)."""
    name = 'mycrawler_redis'
    redis_key = 'mycrawler:start_urls'

    rules = (
        Rule(LinkExtractor(), callback='parse_page', follow=True),
    )

    def __init__(self, *args, **kwargs):
        domain = kwargs.pop('domain', '')
        self.allowed_domains = filter(None, domain.split(','))
        super(MyCrawler, self).__init__(*args, **kwargs)

    def parse_page(self, response):
      name = response.css('title::text').extract_first()
      url = response.url
      an = re.search('http\:\/\/baijiahao\.baidu\.com\/[\s\S]*',response.url)
      if an:
       article_title = response.xpath('//title/text()').extract()
       article_date = response.xpath('//div[@class="article-source article-source-bjh"]/span[@class="date"]/text()').extract()
       article_time = response.xpath('//div[@class="article-source article-source-bjh"]/span[@class="time"]/text()').extract()
       article_source = response.xpath('//div[@class="article-desc clearfix"]/div[@class="author-txt"]/p[@class="author-name"]/text()').extract()
       article_content = response.xpath('//span[@class="bjh-p"]/text()').extract()
       item = ExampleItem()
        
       item['article_title'] = article_title
       item['article_date'] = article_date
       item['article_time'] = article_time
       item['article_source'] = article_source
       item['article_url'] = response.url
       item['article_content'] = article_content
       yield item   
