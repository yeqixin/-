#coding=utf-8#
import nltk
import jieba
import jieba.analyse
from nltk.tokenize import word_tokenize
import re



import pymongo
connection = pymongo.MongoClient('localhost',27017)
db = connection.baidunews
collection = db.content
collection1 = db["cipin"]
dic1 = []
index = 0
for col in collection.find():
    index = index + 1
    url = col["article_url"]
    
    text =  col["article_content"]
    commentpart = ''.join(text)
    commentpart1 = re.sub("\$([\s\S]*)+|[.{}''"";:!`~@#\$%^&*()-_=+[]|/<>?]+|[/\s+/g]","",commentpart)
    blacklist = [u'-',u'（',u'）',u'《',u'》',u'，',u'。',u'、',u'？',u'“',u'”',u'‘',u'’',u'：','\r','\n',' ','\r\n','/','(',')','.',u'的']
    seg = jieba.cut(commentpart1)
    l = []
    dic = {}
    dic2 = {}
    for i in seg:
      if i in blacklist:
        continue
      l.append(i)
    text1 = " ".join(l)
    
    text2 = nltk.FreqDist(l)
    for i in text2:
       dic[i]=text2[i]
    dic2["commentpart"]=dic
    dic2["url"]=url
    dic2["index"] = str(index)
    dic1.append(dic2)
collection1.insert(dic1)
