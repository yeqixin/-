#coding=utf-8#
from scrapy.spiders import Rule
from scrapy.linkextractors import LinkExtractor
from scrapy_redis.spiders import RedisCrawlSpider

import scrapy
from scrapy.http import Request
from example.items import ExampleItem
import re
import urllib2
import requests
import time
from lxml import etree

import sys
reload(sys)
sys.setdefaultencoding('utf8')


class MyCrawler(RedisCrawlSpider):
    """Spider that reads urls from redis queue (myspider:start_urls)."""
    name = 'mycrawler_redis'
    redis_key = 'mycrawler:start_urls'

    rules = (
        Rule(LinkExtractor(), callback='parse_page', follow=True),
    )

    def __init__(self, *args, **kwargs):
        domain = kwargs.pop('domain', '')
        self.allowed_domains = filter(None, domain.split(','))
        super(MyCrawler, self).__init__(*args, **kwargs)

    def parse_page(self, response):
      name = response.css('title::text').extract_first()
      url = response.url
      an = re.search('http\:\/\/product\.dangdang\.com\/(\d+)\.html$',response.url)
      if an:
        product_title = response.xpath('//title/text()').extract()
        price1 = response.xpath('//p[@id="dd-price"]/text()').extract()
        price = price1[1]
        shop = response.xpath('//a[@target="_blank"]/@title').extract()
        comment_num = response.xpath('//a[@id="comm_num_down"]/text()').extract()
        information = response.xpath('//div[@class="messbox_info"]/span/text()').extract()
        information1 = response.xpath('//div[@class="messbox_info"]/span/a/text()').extract()

        
        item = ExampleItem()
        item["product_url"] = response.url
        item["product_title"] = product_title
        item["price"] = price
        item["comment_num"] = comment_num
        item["information1"] = information1

        try:
          item["shop"] = shop
        except:
          print 'shop not exit!'
        yield item
      
