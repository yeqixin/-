#coding=utf-8#
import nltk
import jieba
import jieba.analyse
from nltk.tokenize import word_tokenize
import pymongo

connection = pymongo.MongoClient("mongodb://localhost:27017")
db = connection.jindong
collection = db.content
collection1 = db["cipin"]
dic1 = []
for col in collection.find():
    url = col["product_url"]
    text =  col["comment_part"]
    commentpart1 = ''.join(text)
    whitelist = [u'快',u'满意',u'赞',u'不错',u'喜欢',u'差评',u'好评',u'慢']
    seg = jieba.cut(commentpart1)
    l = []
    dic = {}
    dic2 = {}
    for i in seg:
      if i in whitelist:
        l.append(i)
    text2 = nltk.FreqDist(l)
    for i in text2:
       dic[i]=text2[i]
    dic2["commentpart"]=dic
    dic2["url"]=url
    dic1.append(dic2)
collection1.insert(dic1)
