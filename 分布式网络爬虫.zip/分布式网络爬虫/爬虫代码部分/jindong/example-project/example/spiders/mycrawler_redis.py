#coding=utf-8#
from scrapy.spiders import Rule
from scrapy.linkextractors import LinkExtractor
from scrapy_redis.spiders import RedisCrawlSpider

import scrapy
from scrapy.http import Request
from example.items import ExampleItem
import re
import urllib2
import requests
import time
from lxml import etree

import sys
reload(sys)
sys.setdefaultencoding('utf8')


class MyCrawler(RedisCrawlSpider):
    """Spider that reads urls from redis queue (myspider:start_urls)."""
    name = 'mycrawler_redis'
    redis_key = 'mycrawler:start_urls'

    rules = (
        Rule(LinkExtractor(), callback='parse_page', follow=True),
    )

    def __init__(self, *args, **kwargs):
        domain = kwargs.pop('domain', '')
        self.allowed_domains = filter(None, domain.split(','))
        super(MyCrawler, self).__init__(*args, **kwargs)

    def parse_page(self, response):
      name = response.css('title::text').extract_first()
      url = response.url
      an = re.search('https\:\/\/item\.jd\.com\/(\d+)\.html$',response.url)
      if an:
        product_title = response.xpath('//title/text()').extract()
        shop = response.xpath('//div[@class="name"]/a[@target="_blank"]/text()').extract()
        if not shop:
           shop = response.xpath('//h3/a[@target="_blank"]/text()').extract()
           if not shop:
                shop.append("京东自营")
        comment_part = response.xpath('//div[@class="i-item"]/div[@class="o-topic"]/strong[@class="topic"]/a/text()').extract()
        pattern = r"(\d+)\.html$"
        id = re.findall(pattern, response.url)
        priceUrl = "https://p.3.cn/prices/mgets?&skuIds=J_"+str(id[0])
        priceData = urllib2.urlopen(priceUrl).read().decode("utf-8", "ignore")
        patt = r'"p":"(\d+\.\d+)"'
        price = re.findall(patt, priceData)
        commentUrl = "https://club.jd.com/comment/productCommentSummaries.action?referenceIds="+str(id[0])
        commentData = urllib2.urlopen(commentUrl).read().decode("utf-8", "ignore")
        patt1 = r'"CommentCount":(\d+)'
        
        comment_num = re.findall(patt1, commentData)

        patt2 = r'"GoodCount":(\d+)'
        good_comment = re.findall(patt2, commentData)
        
        patt3 = r'"GeneralCount":(\d+)'
        general_comment = re.findall(patt3, commentData)

        patt4 = r'"PoorCount":(\d+)'
        poor_comment = re.findall(patt4, commentData)
               
       
        information1 = response.xpath('//ul[@class="parameter2 p-parameter-list"]/li').extract()
        if information1:
            information2 = information1
        else:
            information1 = response.xpath('//ul[@class="p-parameter-list"]/li').extract()
            information2= information1
        information = []
        for inf in information2:
            inf1 = re.sub("<[^>]*>","",inf)
            inf2 = re.sub("\&gt\;","",inf1)
            information.append(inf2)

        
        item = ExampleItem()
        item["information"] = information
        item["product_url"] = response.url
        item["product_title"] = product_title
        item["price"] = price
        item["comment_num"] = comment_num
        item["good_comment"] = good_comment
        item["general_comment"] = general_comment
        item["poor_comment"] = poor_comment
        item["comment_part"] = comment_part

        try:
          item["shop"] = shop
        except:
          print 'shop not exit!'
        yield item
      
