#coding=utf-8#
from scrapy.spiders import Rule
from scrapy.linkextractors import LinkExtractor
from scrapy_redis.spiders import RedisCrawlSpider

import scrapy
from scrapy.http import Request
from example.items import ExampleItem
import re
import urllib2
import requests
import time
from lxml import etree

import sys
reload(sys)
sys.setdefaultencoding('utf8')


class MyCrawler(RedisCrawlSpider):
    """Spider that reads urls from redis queue (myspider:start_urls)."""
    name = 'mycrawler_redis'
    redis_key = 'mycrawler:start_urls'

    rules = (
        Rule(LinkExtractor(), callback='parse_page', follow=True),
    )

    def __init__(self, *args, **kwargs):
        domain = kwargs.pop('domain', '')
        self.allowed_domains = filter(None, domain.split(','))
        super(MyCrawler, self).__init__(*args, **kwargs)

    def parse_page(self, response):
      name = response.css('title::text').extract_first()
      url = response.url
      an = re.search('https\:\/\/item\.taobao\.com\/[\s\S]*',response.url)
      if an:
        product_title = response.xpath('//h3[@class="tb-main-title"]/text()').extract()
        price = response.xpath('//em[@class="tb-rmb-num"]/text()').extract()
        shop = response.xpath('//a[@class="tb-seller-name"]/text()').extract()
        information =  response.xpath('//ul[@class="attributes-list"]/li/text()').extract()
        

        
        item = ExampleItem()
        item["product_url"] = response.url
        item["product_title"] = product_title
        item["price"] = price
        item["information"] = information

        try:
          item["shop"] = shop
        except:
          print 'shop not exit!'
        yield item
      
