<html>
 <head>
  <title>商品信息参数</title>
  <meta charset="utf-8">
  <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
  <script type="text/javascript" src="js/bootstrap-table.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <script type="text/javascript" src="js/echarts.js"></script>
  <link rel="stylesheet" href="css/bootstrap-table.css" />
  <link rel="stylesheet" href="css/bootstrap.min.css" rel="external nofollow" />
 </head>
 <body>
  <div class="demo2">
    <p style="font-size:28px">商品具体信息参数</p>
   <div style="float:right;font-size:18px">
    <a href="taobao.php">返回</a>
   </div>
  </div>
  <hr style=" height:2px;border:none;border-top:2px solid #D3D3D3;" />
  <div class="demo1">
   <table class="table table-condensed">
    <?php
     $con = new MongoDB\Driver\Manager('mongodb://127.0.0.1:27017');
     $query = new MongoDB\Driver\Query([]);
     $rows = $con->executeQuery('taobao.content',$query);
     $row = array();
     $i=0;
     $j=0;
     $url = $_GET['m'];
     foreach ($rows as $r){
      $i++;
      foreach($r as $key => $value){
       $row[$i][$key] = $value;
      }
     }

     $i=0;
     
     foreach ($row as $r){
      $j++;
      $result_url = explode('&', $r["product_url"]);
      if($result_url[0] == $url){
       while($r["information"][$i]){
        echo "<tr>","<td>";
        print_r($r["information"][$i]);
        echo "</td>","</tr>";
        $i++;
       }
       break;
      }
     }
    ?>
   </table>
  </div>
 </body>
</html>
