    var timer,timer1;
    var flag = false;
    var sys_second = 0;
    var data;
    var dataitem = [];
    
    function arrTest(){
                 $.ajax({
                  type:"post",
                  async:false,
                  url:"monitor_middleware.php",
                  data1:{},
                  dataType:"json",
                  success:function(result){
                    if (result) {
                      data = result;
                    }
                  }
                 })
                return data;
               }
 
    function arrTest1(){
                 $.ajax({
                  type:"post",
                  async:false,
                  url:"monitor_middleware1.php",
                  data1:{},
                  dataType:"json",
                  success:function(result){
                    if (result) {
                      dataitem = result;
                    }
                  }
                 })
                return dataitem;
               }     

    function countDown() {
        if (flag == true) {
            return;
        }
        flag = true;
        var minute_elem = $('#colockbox1').find('.minute');
        var second_elem = $('#colockbox1').find('.second');
        var data_elem = $('#colockbox1').find('.data');
        var dataitem_elem = $('#colockbox1').find('.dataitem');
        timer = setInterval(function () {
            if (sys_second < 1000000) {
                sys_second += 1;	   
                
                var minute = Math.floor(sys_second / 60);
                var second = Math.floor(sys_second % 60);
                $(minute_elem).text(minute < 10 ? "0" + minute : minute);//计算分钟
                $(second_elem).text(second < 10 ? "0" + second : second);//计算秒杀
                

            } else {
                $(minute_elem).text("00");
                $(second_elem).text("00");
                clearInterval(timer);
                flag = false;
            }
        }, 1015);
       timer1 = setInterval(function () {
             arrTest();
             arrTest1();
             $(data_elem).text(data);
             $(dataitem_elem).text(dataitem);
        },500);
    }
    function reset() {
		var node = document.getElementById("tishi");
        if (node != null) {
            node.pause();
        }
        $("#time").removeClass("fronts_red");
        var minute_elem = $('#colockbox1').find('.minute');
        var second_elem = $('#colockbox1').find('.second');
        clearInterval(timer);
        flag = false;
        sys_second = 0;
        $(minute_elem).text("00");
        $(second_elem).text("00");
    }

    function stop() {
		var node = document.getElementById("tishi");
        if (node != null) {
            node.pause();
        }
        clearInterval(timer);
        clearInterval(timer1);
        flag = false;
    }
