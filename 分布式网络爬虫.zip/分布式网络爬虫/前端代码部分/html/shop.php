<html>
 <head>
  <meta charset="utf-8">
  <title>shop</title>
  <link rel="stylesheet" href="css/bootstrap-table.css" />
 </head>
 <body>
  <?php
   $product = $_POST['product'];
   $shop = $_POST['shop'];
   $pricemin = $_POST['pricemin']; 
   $pricemax = $_POST['pricemax'];
   $salesmin = $_POST['salesmin'];
   $salesmax = $_POST['salesmax'];
   
   $servername = "localhost";
   $username = "root";
   $password = "19970629";
   $db_name = "shop_record";

   $conn = new mysqli($servername, $username, $password,$db_name);
   if($conn -> connect_error){
     die("连接失败：". $conn->connect_error);
   }
   $conn->query("SET NAMES utf8");
   $sql = "insert into record(product,shop,pricemin,pricemax,salesmin,salesmax) values ('".$product."','".$shop."','".$pricemin."','".$pricemax."','".$salesmin."','".$salesmax."')";
   $result = $conn->query($sql);
   $conn->close();
  ?>

  <div class="shop">
    <div class="shop_img"><a href="jd.php"><img src="/img/jd.jpeg"></img></a></div>
    <div class="shop_img"><a href="taobao.php"><img src="/img/taobao.jpeg"></img></a></div>
    <div class="shop_img"><a href="dangdang.php"><img src="/img/dangdang.jpeg"></img></a></div>
  </div>
 </body>
</html>
