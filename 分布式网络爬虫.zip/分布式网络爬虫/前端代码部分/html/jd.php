<html>
 <head>
  <meta charset="utf-8">
  <title>京东爬虫</title>
  <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
  <script type="text/javascript" src="js/bootstrap-table.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/bootstrap-table.css" />
  <link rel="stylesheet" href="css/bootstrap.min.css" rel="external nofollow" />

  <script type="text/javascript">
   $(document).ready(function(){
    $("#table_page").bootstrapTable({
	 columns:[{
	  field:'Title',
	  title:'商品名称'
	 },{
          field:'Shop',
          title:'商店名称'
         },{
	  field:'Price',
	  title:'商品价格'
	 },{
	  field:'Comment',
	  title:'商品评论'
	 },{
          field:'detail',
          title:'查看详情'
           },]
	});
   });
  </script>
 </head>

 <body>
 <!--表格-->
 <div class="demo">
  <table class="table table-bordered" id="table_page"
         data-pagination="true"
         data-side-pagination="client"
	 data-page-size="15">

   <?php
    $servername = "localhost";
    $username = "root";
    $password = "19970629";
    $db_name = "shop_record";
    $count = 0;    

    $conn = new mysqli($servername, $username, $password,$db_name);
    if($conn -> connect_error){
     die("连接失败：". $conn->connect_error);
    }
    $conn->query("SET NAMES utf8");
    $sql = "select * from record";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
     while($row = $result->fetch_assoc()) {
         $count++;
         if($count == $result->num_rows){
          $product = $row["product"];
          $shop = $row["shop"];
          $pricemin = $row["pricemin"];
          $pricemax = $row["pricemax"];
          $salesmin = $row["salesmin"];
          $salesmax = $row["salesmax"];
         }
      }
     } 
    
    $con = new MongoDB\Driver\Manager('mongodb://127.0.0.1:27017');
    $query = new MongoDB\Driver\Query([]);
    $rows = $con->executeQuery('jindong.content',$query);
    
    $row = array();
    $i=0;
    
    foreach ($rows as $r){
     $i++;
     foreach($r as $key => $value){
      $row[$i][$key] = $value;
     }
    }
    foreach($row as $r){
     $result = strpos($r["product_title"][0],$product);
     $result1 = strpos($r["shop"][0],$shop);
     if($shop != ""){
      if(($result!==false)&&($result1!==false)&&($r["price"][0]<$pricemax)&&($r["price"][0]>$pricemin)&&($r["comment_num"][0]<$salesmax)&&($r["comment_num"][0]>$salesmin)){
       echo "<tr>";
       echo "<td>","<a href=",$r["product_url"],">",$r["product_title"][0],"</a>","</td>";
       echo "<td>",$r["shop"][0],"</td>";
       echo "<td>",$r["price"][0],"</td>";
       echo "<td>",$r["comment_num"][0],"</td>";
       echo "<td>","<a href='jd_productinf.php?m=",$r["product_url"],"'>查看详情</a>","</td>";
       echo "</tr>";
      }
     }
     else{
      if(($result!==false)&&($r["price"][0]<$pricemax)&&($r["price"][0]>$pricemin)&&($r["comment_num"][0]<$salesmax)&&($r["comment_num"][0]>$salesmin)){
       echo "<tr>";
       echo "<td>","<a href=",$r["product_url"],">",$r["product_title"][0],"</a>","</td>";
       echo "<td>",$r["shop"][0],"</td>";
       echo "<td>",$r["price"][0],"</td>";
       echo "<td>",$r["comment_num"][0],"</td>";
       echo "<td>","<a href='jd_productinf.php?m=",$r["product_url"],"'>查看详情</a>","</td>";
       echo "</tr>";
      }
     }
    }
   ?>
   </table>
  </div>
 </body>
</html>
