<?php
    $redis = new Redis() or die("Cannot load Redis module.");
    $redis->connect('localhost',6379);
    $row = $redis->lrange("mycrawler_redis:items",-1,-1);
    $data = json_encode($row);
    echo $data;
?>
