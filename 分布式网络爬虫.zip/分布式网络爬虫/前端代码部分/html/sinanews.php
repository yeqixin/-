<html>
 <head>
  <meta charset="utf-8">
  <title>新浪新闻爬虫</title>
  <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
  <script type="text/javascript" src="js/bootstrap-table.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/bootstrap-table.css" />
  <link rel="stylesheet" href="css/bootstrap.min.css" rel="external nofollow" />

  <script type="text/javascript">
   $(document).ready(function(){
    $("#table_page").bootstrapTable({
	 columns:[{
	  field:'Title',
	  title:'新闻题目'
	 },{
	  field:'Time',
	  title:'新闻发布时间'
	 },{
	  field:'Souce',
	  title:'新闻来源'
	 },{
          field:'detail',
          title:'查看详情'
           },]
	});
   });
  </script>
 </head>

 <body>
<!--表格-->
 <div class="demo">
  <table class="table table-bordered" id="table_page"
         data-pagination="true"
         data-side-pagination="client"
	 data-page-size="15">

   <?php
    $servername = "localhost";
    $username = "root";
    $password = "19970629";
    $db_name = "news_record";
    $count = 0;    

    $conn = new mysqli($servername, $username, $password,$db_name);
    if($conn -> connect_error){
     die("连接失败：". $conn->connect_error);
    }
    $conn->query("SET NAMES utf8");
    $sql = "select * from record";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
     while($row = $result->fetch_assoc()) {
         $count++;
         if($count == $result->num_rows){
          $date = $row["date"];
          $title = $row["title"];
          $source = $row["source"];
         }
     }
    } 

    $con = new MongoDB\Driver\Manager('mongodb://127.0.0.1:27017');
    $query = new MongoDB\Driver\Query([]);
    $rows = $con->executeQuery('sinanews.content',$query);
    
    
    $row = array();
    $i=0;
    
    foreach ($rows as $r){
     $i++;
     foreach($r as $key => $value){
      $row[$i][$key] = $value;
     }
    }
   
    foreach($row as $r){
     $result = strpos($r["article_title"][0],$title);
     $result1 = strpos($r["article_source"][0],$source);
     $result2 = strpos($r["article_date"][0],$date);
     if($source != ""){
      if(($result!==false)&&($result1!==false)&&($result2!==false)){
       echo "<tr>";
       echo "<td>","<a href=",$r["article_url"],">",$r["article_title"][0],"</a>","</td>";
       echo "<td>",$r["article_time"][0],"</td>";
       echo "<td>",$r["article_source"][0],"</td>";
       echo "<td>","<a href='sinanewsinf.php?m=",$r["article_url"],"'>查看详情</a>","</td>";
       echo "</tr>";
      }
     }
     else{
      if(($result!==false)&&($result2!==false)){
       echo "<tr>";
       echo "<td>","<a href=",$r["article_url"],">",$r["article_title"][0],"</a>","</td>";
       echo "<td>",$r["article_time"][0],"</td>";
       echo "<td>",$r["article_source"][0],"</td>";
       echo "<td>","<a href='sinanewsinf.php?m=",$r["article_url"],"'>查看详情</a>","</td>";
       echo "</tr>";
      }
     }
    }
   ?>
   </table>
  </div>
 </body>
</html>
