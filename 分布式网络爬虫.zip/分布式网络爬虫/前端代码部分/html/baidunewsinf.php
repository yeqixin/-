<html>
 <head>
  <title>news words</title>
  <meta charset="utf-8">
  <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
  <script type="text/javascript" src="js/bootstrap-table.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <script type="text/javascript" src="js/echarts.js"></script>
  <link rel="stylesheet" href="css/bootstrap-table.css" />
  <link rel="stylesheet" href="css/bootstrap.min.css" rel="external nofollow" />
 </head>
 <body>
  <div class="demo2">
    <p style="font-size:28px">文字分析</p>
  </div>
  <hr style=" height:2px;border:none;border-top:2px solid #D3D3D3;" />

  <div id="main" class="demo3"></div>
  <div class="demo3">
   <h4>article</h4>
   <?php
     $con = new MongoDB\Driver\Manager('mongodb://127.0.0.1:27017');
     $query = new MongoDB\Driver\Query([]);
     $rows = $con->executeQuery('baidunews.content',$query);
     $row = array();
     $i=0;
     $j=0;
     $url = $_GET['m'];

     foreach ($rows as $r){
      $i++;
      foreach($r as $key => $value){
       $row[$i][$key] = $value;
      }
     }
     
     $i=0;
     foreach ($row as $r){
      $j++;
      if($r["article_url"]==$url){
       while($r["article_content"][$i]){
       echo "<p style='font-size:16px;'>",$r["article_content"][$i],"</p>";
       $i++;
       }
       break;
      }
     }
    ?>
    <br><br>
  </div>
  <script type="text/javascript">
        var count = "<?php echo $j-1; ?>";
        // 路径配置
        require.config({
            paths: {
                echarts: 'http://echarts.baidu.com/build/dist'
            }
        });
        // 使用
        require(
            [
                'echarts',
                'echarts/chart/wordCloud' // 加载模块
            ],
            function (ec) {
                // 基于准备好的dom，初始化echarts图表
                var myChart = ec.init(document.getElementById('main')); 
                var commentpart = [];
                function arrTest(){
                 $.ajax({
                  type:"post",
                  async:false,
                  url:"baidunews_middleware.php",
                  data:{},
                  dataType:"json",
                  success:function(result){
                    if (result) {
                      for (var i = 0; i < result.length; i++) {
                          commentpart.push(result[i].commentpart);
                      }
                    }
                  }
                 })
                return commentpart;
               }
                
                function createRandomItemStyle() {
                  return {
                    normal: {
                     color: 'rgb(' + [
                       Math.round(Math.random() * 160),
                       Math.round(Math.random() * 160),
                       Math.round(Math.random() * 160)
                    ].join(',') + ')'
                   }
                 };
               }
             
               arrTest();              
                
               var commentpart1 = {};
               var commentpart1 = commentpart[count];
               var data = [];
               var i=0;
               for(var key in commentpart1){
                 commentpart2 = {};
                 commentpart2["name"] = key;
                 commentpart2["value"] = commentpart1[key]*20;
                 commentpart2["itemStyle"] = createRandomItemStyle();
                 data.push(commentpart2);
                 i++;
                 if(i>40)
                   break;
               } 
            
            option = {
              title: {
                text: 'wordcloud',
                link: ''
              },
              tooltip: {
               show: true
              },
              series: [{
               name: 'frequency',
               type: 'wordCloud',
               size: ['80%', '80%'],
               textRotation : [0, 45, 90, -45],
               textPadding: 0,
               autoSize: {
                 enable: true,
                 minSize: 14
               },
              data:data
             }]
          };
          // 为echarts对象加载数据 
          myChart.setOption(option); 
        }
       );
  </script>
 </body>
</html>
