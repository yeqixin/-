<!doctype html>
<html>
 <head>
  <meta charset="utf-8">
  <title>监控界面</title>
  <script src="js/jquery-1.11.1.min.js" type="text/javascript"></script>
  <link href="css/time.css" rel="stylesheet">
  <script src="js/time.js" type="text/javascript"></script>
 </head>
 <body>
  <p style="text-align:center;font-size:24px;">爬虫监控界面</p>
  <hr>
  <br>
  <div align="center">
   <div class="contern" align="left">
    <div class="pagemiddle">
     <div id="colockbox1" class="authorization_box">
      <p>&nbsp;&nbsp;已爬去数据条数:<span class="data">0</span></p>
      <p align="center"><span class="fronts" id="time"><span class="minute">00</span>:<span class="second">00</span></span></p>
      <div style="overflow:scroll; width:900px; height:200px;margin-left:130px;margin-bottom:20px;" >
       <span class="dataitem"></span>
      </div>
     </div>
     <div class="pos_abs">
      <a href="#" onclick="countDown()" style="margin-left:50px">开始</a>
      <a href="#" onclick="stop()" style="margin-left:50px">暂停</a>
      <a href="index.php" style="margin-left:50px">返回</a>
     </div>
    </div>
   </div>
  </div>
</body>
</html>
