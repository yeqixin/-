<?php
    $redis = new Redis() or die("Cannot load Redis module.");
    $redis->connect('localhost',6379);
    $row = $redis->llen("mycrawler_redis:items");
    $data = json_encode($row);
    echo $data;
?>
