<html>
 <head>
  <meta charset="utf-8">
  <title>search</title>
  <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
  <script type="text/javascript" src="js/bootstrap-table.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/bootstrap-table.css" />
  <link rel="stylesheet" href="css/bootstrap.min.css" rel="external nofollow" />
  <link rel="stylesheet" href="css/search.css" />
  <script language="javascript" src="jquery-3.1.1.min.js"></script>
  <script language="javascript">
   $(function(){
    $(".tab_menu ul li").click(function(){
     $(this).addClass("on").siblings().removeClass("on");
       var index=$(this).index();
       $(".tab_box > div").eq(index).show().siblings().hide();
    });
   });
  </script>

  <script language="javascript">
   var shopflag = true;
   var shopflag1 = true;
   var shopflag2 = true;
   var newsflag = true;
   var newsflag1 = true;
   function checkshop(shop_research){
    if($("#product").val()==""){
     $("#productalarm").show();
     shopflag = false;
    }
    else{
     $("#productalarm").hide();
     shopflag = true;
    }
    if(($("#pricemin").val()=="")||($("#pricemax").val()=="")){
     $("#pricealarm").show();
     shopflag1 = false;
    } 
    else{
     $("#pricealarm").hide();
     shopflag1 = true;
    }
    if(($("#salesmin").val()=="")||($("#salesmax").val()=="")){
     $("#salesalarm").show();
     shopflag2 = false;
    } 
    else{
     $("#pricealarm").hide();
     shopflag2 = true;
    }
    if(shopflag && shopflag1 && shopflag2){
     $(".shop_research").submit();
     return true; 
    }
    else{
     return false;
    }
    return shopflag;
   }


   function checknews(news_research){
    if($("#title").val()==""){
     $("#titlealarm").show();
     newsflag = false;
    }
    else{
     $("#titlealarm").hide();
     newsflag = true;
    }
    if($("#date").val()==""){
     $("#datealarm").show();
     newsflag1 = false;
    }
    else{
     $("#datealarm").hide();
     newsflag1 = true;
    }
    if(newsflag && newsflag1){
     $(".shop_research").submit();
     return true; 
    }
    else{
     return false;
    }
    return newsflag;
   }
  </script>
 </head>
 <body>
  <div class="tab">
   <div class="tab_menu">
    <ul>
     <li class="on">商品查询</li>
     <li>爬虫监控</li>
     <li>新闻查询</li>
    </ul>
   </div>
   <div class="tab_box">
    <div>
     <div class="jd_search">
      <form  action="shop.php" method="post" class="shop_research" onsubmit="return checkshop()">
       <p>
        商品名称:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="product" style="height:30px;width:400px;" placeholder="请输入商品名称" id="product">
        <span id="productalarm" style="color:red;">请输入商品名称</span>
       </p>
       <p>
        商店名称:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="shop" style="height:30px;width:400px;" placeholder="请输入商店名称 选填">
       </p>
       <p>
        商品价格:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="pricemin" style="height:30px;width:150px;" placeholder="最小值" id="pricemin">
        --<input type="text" name="pricemax" style="height:30px;width:150px;" placeholder="最大值" id="pricemax">
        <span id="pricealarm" style="color:red;">请输入价格区间</span>
       </p>
       <p>
        售出数量:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="salesmin" style="height:30px;width:150px;" placeholder="最小值" id="salesmin">
        --<input type="text" name="salesmax" style="height:30px;width:150px;" placeholder="最大值" id="salesmax">
       <span id="salesalarm" style="color:red;">请输入售出数量</span>
       </p>
       <p style="margin-left:200px;"><input type="submit" style="width:150px;"></p>
      </form>
     </div>
    </div>
    <div>
     <div class="jd_search1">
      <p style="margin-left:130px;margin-top:100px;font-size:28px;"><a href="monitor.php">监控界面链接</a></p>
      <p style="font-size:19px;">监控界面包括计时器和动态更新缓存的数据条数</p>
      <p style="font-size:19px;">以此可以监控爬虫是否正常工作,以及估算爬虫的效率</p>
     
     </div>
    </div>
    <div>
     <div class="jd_search">
      <form  action="news.php" method="post" class="news_research" onsubmit="return checknews()">
       <p>新闻标题:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="text" name="title" style="height:30px;width:400px;" placeholder="请输入新闻标题" id="title">
        <span id="titlealarm" style="color:red;">请输入新闻标题</span>
       </p>
       <p>新闻来源:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="text" name="source" style="height:30px;width:400px;" placeholder="请输入新闻来源 选填">
       </p>
       <p>发表时间:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="text" name="date" style="height:30px;width:400px;" placeholder="05-08" id="date">
        <span id="datealarm" style="color:red;">请输入发表时间</span>
       </p>
       <p style="margin-left:200px;"><input type="submit" style="width:150px"></p>
      </form>
     </div>
    </div> 
   </div>
  </div>
 </body>
</html>







