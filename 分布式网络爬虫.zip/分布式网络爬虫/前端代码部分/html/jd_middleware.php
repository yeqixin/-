<?php
    $con = new MongoDB\Driver\Manager('mongodb://127.0.0.1:27017');
    $query = new MongoDB\Driver\Query([]);
    $rows = $con->executeQuery('jindong.content',$query);
    $row = array();
    $i=0;
    
    foreach ($rows as $r){
     foreach($r as $key=>$value){
      if($key=="good_comment")
       $row[$i]["good_comment"] = $value[0];
      if($key=="general_comment")
       $row[$i]["general_comment"] = $value[0];
      if($key=="poor_comment")
       $row[$i]["poor_comment"] = $value[0];
     }
     $i++;
    }
    $data = json_encode($row);
    echo $data;
?>
