<?php
    $con = new MongoDB\Driver\Manager('mongodb://127.0.0.1:27017');
    $query = new MongoDB\Driver\Query([]);
    $rows = $con->executeQuery('baidunews.cipin',$query);
    $row = array();
    $i=0;
    
    foreach ($rows as $r){
     foreach($r as $key=>$value){
        $row[$i][$key] = $value;
     }
     $i++;
    }
    $data = json_encode($row);
    echo $data;
?>
