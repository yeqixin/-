<html>
 <head>
  <title>商品信息参数</title>
  <meta charset="utf-8">
  <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
  <script type="text/javascript" src="js/bootstrap-table.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <script type="text/javascript" src="js/echarts.js"></script>
  <link rel="stylesheet" href="css/bootstrap-table.css" />
  <link rel="stylesheet" href="css/bootstrap.min.css" rel="external nofollow" />
 </head>
 <body>
  <div class="demo2">
    <p style="font-size:28px">商品具体信息参数</p>
   <div style="float:right;font-size:18px">
    <a href="jd.php">返回</a>
   </div>
  </div>
  <hr style=" height:2px;border:none;border-top:2px solid #D3D3D3;" />
  <div class="demo1">
   <table class="table table-condensed">
    <?php
     $con = new MongoDB\Driver\Manager('mongodb://127.0.0.1:27017');
     $query = new MongoDB\Driver\Query([]);
     $rows = $con->executeQuery('jindong.content',$query);
     $row = array();
     $i=0;
     $j=0;
     $url = $_GET['m'];

     foreach ($rows as $r){
      $i++;
      foreach($r as $key => $value){
       $row[$i][$key] = $value;
      }
     }

     $i=0;

     foreach ($row as $r){
      $j++;
      if($r["product_url"]==$url){
       while($r["information"][$i]){
        echo "<tr>","<td>";
        print_r($r["information"][$i]);
        echo "</td>","</tr>";
        $i++;
       }
       break;
      }
     }
    ?>
   </table>
  </div>

  <div id="main" class="demo3"></div>
  <br><br>
  <p style="text-align:center;font-weight:bold;font-size:18px;">商品评论内容词频分析</p>
  <div id="main1" class="demo3"></div>

  <script type="text/javascript">
        var count = "<?php echo $j-1; ?>";
        // 路径配置
        require.config({
            paths: {
                echarts: 'http://echarts.baidu.com/build/dist'
            }
        });
        
        // 使用
        require(
            [
                'echarts',
                'echarts/chart/pie' // 加载饼状图模块
            ],
            function (ec) {
                // 基于准备好的dom，初始化echarts图表
                var myChart = ec.init(document.getElementById('main')); 
                var goodcomment=[],generalcomment=[],poorcomment=[];
                function arrTest(){
                 $.ajax({
                  type:"post",
                  async:false,
                  url:"jd_middleware.php",
                  data:{},
                  dataType:"json",
                  success:function(result){
                    if (result) {
                      for (var i = 0; i < result.length; i++) {
                          goodcomment.push(result[i].good_comment);
                          generalcomment.push(result[i].general_comment);
                          poorcomment.push(result[i].poor_comment);
                      }
                    }
                  }
                 })
                return goodcomment,generalcomment,poorcomment;
               }
               arrTest();
                
                var option = {
                  title : {
                   text: '商品评价饼状图',
                   subtext: '',
                   x:'center'
                  },
                  tooltip : {
                   trigger: 'item',
                   formatter: "{a} <br/>{b} : {c} ({d}%)"
                  },
                  legend: {
                   orient : 'vertical',
                   x : 'left',
                   data:['好评','中评','差评']
                  },
                  toolbox: {
                   show : true,
                   feature : {
                    mark : {show: true},
                    dataView : {show: true, readOnly: false},
                    magicType : {
                    show: true, 
                    type: ['pie'],
                    option: {
                    funnel: {
                        x: '25%',
                        width: '50%',
                        funnelAlign: 'left',
                        max: 1548
                  }
                }
              },
              restore : {show: true},
              saveAsImage : {show: true}
             }
            },
            calculable : true,
            series : [
            {
             name:'评价数',
             type:'pie',
             radius : '55%',
             center: ['50%', '60%'],
             data:[
                {value:goodcomment[count], name:'好评'},
                {value:generalcomment[count], name:'中评'},
                {value:poorcomment[count], name:'差评'}
             ]
            }
           ]
          };
        
                // 为echarts对象加载数据 
                myChart.setOption(option); 
            }
         );
  </script>

  <script type="text/javascript">
        // 路径配置
        require.config({
            paths: {
                echarts: 'http://echarts.baidu.com/build/dist'
            }
        });
        
        // 使用
        require(
            [
                'echarts',
                'echarts/chart/bar' // 使用柱状图就加载bar模块，按需加载
            ],
            function (ec) {
                // 基于准备好的dom，初始化echarts图表
                var myChart = ec.init(document.getElementById('main1')); 
                var commentpart = [];
                function arrTest(){
                 $.ajax({
                  type:"post",
                  async:false,
                  url:"jd_middleware1.php",
                  data:{},
                  dataType:"json",
                  success:function(result){
                    if (result) {
                      for (var i = 0; i < result.length; i++) {
                          commentpart.push(result[i].commentpart);
                      }
                    }
                  }
                 })
                return commentpart;
               }
               arrTest();              
                
               var commentpart1 = {};
               var commentpart1 = commentpart[count];
               var key1 = [],value = [];
               var max1=-1,min1=100000,count1=0,countmax,countmin;
               for(var key in commentpart1){
                 key1 = key1.concat(key);
                 value.push(commentpart1[key]);
                 if(commentpart1[key] >= max1){
                    max1 = commentpart1[key];
                    countmax = count1;
                 }
                 if(commentpart1[key] <= min1){
                    min1 = commentpart1[key];
                    countmin = count1;
                 }
                 count1++;
               }
               var option = {
                     title : {
                        text: '',
                        subtext: ''
                     },
                     tooltip : {
                        trigger: 'axis'
                     },
                     legend: {
                        data:['词频数']
                     },
                     toolbox: {
                        show : true,
                        feature : {
                          mark : {show: true},
                          dataView : {show: true, readOnly: false},
                          restore : {show: true},
                          saveAsImage : {show: true}
                       }
                    },
                    calculable : true,
                    xAxis : [
                      {
                        type : 'category',
                        data :  key1
                      }
                   ],
                   yAxis : [
                     {
                       type : 'value'
                     }
                   ],
                   series : [
                   {
                      name:'词频数',
                      type:'bar',
                      data:value,
                      markPoint : {
                        data : [
                          {name : '年最高', value : max1, xAxis: countmax, yAxis: max1, symbolSize:18},
                          {name : '年最低', value : min1, xAxis: countmin, yAxis: min1}
                        ]
                      },
                      markLine : {
                        data : [
                        {type : 'average', name : '平均值'}
                        ]
                      }
                    }
                  ]
                 };
        
                // 为echarts对象加载数据 
                myChart.setOption(option); 
            }
        );
    </script>
  
 </body>
</html>
